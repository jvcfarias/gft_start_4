using System; 

class Teste
{
    public static void Main()
    { 
        Console.WriteLine("Olá Bira e Clécio! \nSou time .NET e estou ansioso pra trabalhar com vocês. \nQuaisquer sugestões e correções, ficarei feliz em ouvi-las futuramente.");
        Console.WriteLine("\nSetorizei em pastas. \nAguardo ansiosamente a oportunidade de trocarmos conhecimento. ")
    }