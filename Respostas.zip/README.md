<h1>Teste Técnico GFT Starter 4 </h1>

Clécio e Bira, 

Dêem as boas vindas ao mais novo estagiário da <strong>GFT</strong> :happy:

Brincadeiras à parte, estou ansioso pela oportunidade de contribuir com a empresa e de nos ajudarmos mutuamente no ambiente de aprendizado contínuo que pretendo contribuir positivamente. 



Aguardando ansiosamente o contato e disponível para início imediato. 

:email: farias.joaovictor@gmail.com

<strong>João Victor Cordeiro Farias</strong>

