/*Exercicio2
Visualizar pasta obj
*/

namespace Teste_GFT.Exercicio2
{
    public interface calculosGerais
    {
        public virtual Formato()
        {
            Console.WriteLine(A);
        }
    }
}